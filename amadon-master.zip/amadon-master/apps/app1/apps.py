from django.apps import AppConfig


class PoorlyCodedStoreConfig(AppConfig):
    name = 'app1'
