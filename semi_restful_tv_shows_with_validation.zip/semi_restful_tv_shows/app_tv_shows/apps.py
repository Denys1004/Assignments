from django.apps import AppConfig


class AppTvShowsConfig(AppConfig):
    name = 'app_tv_shows'
